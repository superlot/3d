A Pen created at CodePen.io. You can find this one at http://codepen.io/superlot/pen/BQOxZz.

 This is the pen to my article about scaling iFrames with CSS transforms. (http://codepen.io/herschel666/blog/scaling-iframes-css-transforms)