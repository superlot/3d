A Pen created at CodePen.io. You can find this one at http://codepen.io/superlot/pen/ayzvja.

 Scaling videos is different than images because videos don’t retain their proportions.